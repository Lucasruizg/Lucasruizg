# PING & PONG

![Portada retro del proyecto](docs/cartucho.png)

Simulador visual de una solicitud ICMP entre dos redes conectadas por dos routers. Usa direcciones reservadas para documentación y no envía paquetes reales.

## Cómo probarlo

Abre `index.html` en un navegador. Pulsa **Lanzar ping** para ver la ida y la vuelta. Activa **Quitar la ruta de retorno de Router 2** y repite. La solicitud llega al Equipo B, pero Router 2 descarta la respuesta porque no tiene ruta hacia la red del Equipo A.

Ejecuta las pruebas de ambos recorridos con Node.js 18 o superior y `node --test`.

![Simulación de un ping correcto en escritorio](docs/ping-correcto.png)

[Ver la captura del escenario sin ruta de retorno en móvil](docs/sin-retorno.png).
