const nodes = ['a', 'r1', 'r2', 'b'];
const names = { a: 'Equipo A', r1: 'Router 1', r2: 'Router 2', b: 'Equipo B' };

function simulatePing(missingRoute) {
  const request = nodes.map(node => ({ node, phase: 'Solicitud ICMP' }));
  const reply = (missingRoute ? ['b', 'r2'] : [...nodes].reverse())
    .map(node => ({ node, phase: 'Respuesta ICMP' }));
  if (missingRoute) reply[1].dropped = true;
  return [...request, ...reply];
}

if (typeof module !== 'undefined') module.exports = { simulatePing };

if (typeof document !== 'undefined') {
  const button = document.querySelector('#send');
  const toggle = document.querySelector('#missing');
  const status = document.querySelector('#status');
  const trace = document.querySelector('#trace');

  button.addEventListener('click', async () => {
    const missing = toggle.checked;
    const steps = simulatePing(missing);
    trace.replaceChildren();
    button.disabled = toggle.disabled = true;
    status.textContent = 'Ping en curso…';
    const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
    for (const { node, phase, dropped } of steps) {
      document.querySelectorAll('.topology div').forEach(box => box.classList.remove('active', 'drop'));
      document.querySelector(`[data-node="${node}"]`).classList.add(dropped ? 'drop' : 'active');
      const item = document.createElement('li');
      item.textContent = `${phase} · ${names[node]}${dropped ? ' · respuesta descartada' : ''}`;
      trace.append(item);
      if (!reducedMotion) await new Promise(resolve => setTimeout(resolve, 250));
    }
    status.textContent = missing
      ? 'Sin respuesta. Router 2 no tiene ruta hacia 192.0.2.0/24 y descarta la respuesta.'
      : 'Ping correcto. La respuesta vuelve al Equipo A.';
    button.disabled = toggle.disabled = false;
  });
}
