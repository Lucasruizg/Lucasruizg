const { test } = require('node:test');
const assert = require('node:assert/strict');
const { simulatePing } = require('./app');

test('la respuesta vuelve por los dos routers', () => {
  const trace = simulatePing(false);
  assert.deepEqual(trace.map(step => step.node), ['a', 'r1', 'r2', 'b', 'b', 'r2', 'r1', 'a']);
  assert.equal(trace.at(-1).phase, 'Respuesta ICMP');
  assert.equal(trace.some(step => step.dropped), false);
});

test('Router 2 descarta la respuesta sin ruta de retorno', () => {
  const trace = simulatePing(true);
  assert.deepEqual(trace.slice(4).map(step => step.node), ['b', 'r2']);
  assert.equal(trace.at(-1).dropped, true);
});
