# RACK CHECK

![Portada retro del proyecto](docs/cartucho.png)

Herramienta de terminal para revisar un inventario CSV. Detecta direcciones inválidas o duplicadas, interfaces sin asignar y campos obligatorios vacíos. Acepta IP individuales IPv4 e IPv6.

## Cómo probarlo

Con Python 3.9 o superior, desde la carpeta del proyecto:

```sh
python rack_check.py ejemplo.csv
python -m unittest -v
```

El CSV debe estar en UTF-8 y tener las columnas `equipo,interfaz,ip`. El ejemplo es ficticio y usa direcciones reservadas para documentación salvo la IP inválida deliberada. Los códigos de salida son 0 si todo es correcto, 1 si hay incidencias y 2 si el archivo no se puede leer o su cabecera no es válida.

![Salida real del comando sobre el inventario ficticio](docs/salida.png)
