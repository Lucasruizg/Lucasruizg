"""Validate a CSV inventory of network interfaces."""
import argparse
import csv
import ipaddress
from pathlib import Path
import sys

FIELDS = ("equipo", "interfaz", "ip")


def inspect_inventory(stream):
    reader = csv.DictReader(stream, strict=True)
    if not reader.fieldnames or not all(field in reader.fieldnames for field in FIELDS):
        raise ValueError("La cabecera debe incluir equipo, interfaz e ip.")

    seen = {}
    errors = []
    for row in reader:
        line = reader.line_num
        if None in row:
            errors.append(f"Fila {line}: columnas de más.")
        values = {field: (row[field] or "").strip() for field in FIELDS}
        for field, value in values.items():
            if not value:
                detail = "interfaz sin asignar" if field == "interfaz" else f"campo {field} vacío"
                errors.append(f"Fila {line}: {detail}.")
        if not values["ip"]:
            continue
        try:
            address = ipaddress.ip_address(values["ip"])
        except ValueError:
            errors.append(f"Fila {line}: IP inválida ({values['ip']}).")
            continue
        previous = seen.setdefault(address, line)
        if previous != line:
            errors.append(f"Fila {line}: IP duplicada ({address}, primera aparición en fila {previous}).")
    return errors


def main(argv=None):
    parser = argparse.ArgumentParser(description="Revisa un inventario CSV de red.")
    parser.add_argument("csv", type=Path)
    args = parser.parse_args(argv)
    try:
        with args.csv.open(encoding="utf-8-sig", newline="") as stream:
            errors = inspect_inventory(stream)
    except (OSError, UnicodeError, ValueError, csv.Error) as error:
        print(f"Error de lectura: {error}", file=sys.stderr)
        return 2
    if errors:
        print(f"RACK CHECK · {len(errors)} incidencias")
        print(*errors, sep="\n")
        return 1
    print("RACK CHECK · inventario correcto")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
