import io
import subprocess
import sys
import unittest

from rack_check import inspect_inventory


class InventoryTests(unittest.TestCase):
    def test_valid_inventory(self):
        rows = io.StringIO("equipo,interfaz,ip\nRouter,eth0,192.0.2.1\n")
        self.assertEqual(inspect_inventory(rows), [])

    def test_duplicate_ipv6_is_normalized(self):
        rows = io.StringIO("equipo,interfaz,ip\nA,eth0,2001:db8::1\nB,eth1,2001:db8:0:0::1\n")
        self.assertIn("IP duplicada", inspect_inventory(rows)[0])

    def test_missing_headers(self):
        with self.assertRaises(ValueError):
            inspect_inventory(io.StringIO("equipo,ip\nA,192.0.2.1\n"))

    def test_example_cli(self):
        output = subprocess.run(
            [sys.executable, "rack_check.py", "ejemplo.csv"], capture_output=True, text=True
        )
        self.assertEqual(output.returncode, 1)
        for expected in ("IP inválida", "IP duplicada", "interfaz sin asignar", "campo ip vacío"):
            self.assertIn(expected, output.stdout)
